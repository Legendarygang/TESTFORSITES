import Logo from "./Logo";

const NAV_ITEMS = ["Device", "Real Stories", "Science", "Plans", "Reach Us"];

interface NavProps {
  onOpenMenu: () => void;
}

export default function Nav({ onOpenMenu }: NavProps) {
  return (
    <nav className="fixed inset-x-0 top-0 z-50 flex items-center justify-between px-5 py-5 sm:px-8 sm:py-6">
      {/* Logo */}
      <div className="flex items-center">
        <Logo />
      </div>

      {/* Desktop center pill nav */}
      <div className="liquid-glass hidden items-center gap-1 rounded-full px-1.5 py-1.5 md:flex">
        {NAV_ITEMS.map((item) => (
          <button
            key={item}
            type="button"
            className="rounded-full px-4 py-2 text-sm font-medium text-white/70 transition-colors duration-200 hover:text-white"
          >
            {item}
          </button>
        ))}
      </div>

      {/* Desktop CTA */}
      <div className="hidden md:block">
        <button
          type="button"
          className="liquid-glass flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium text-white"
        >
          <span className="h-2 w-2 rounded-full bg-green-400" />
          Reserve Yours
        </button>
      </div>

      {/* Mobile hamburger */}
      <button
        type="button"
        onClick={onOpenMenu}
        aria-label="Open menu"
        className="liquid-glass flex h-11 w-11 flex-col items-center justify-center gap-1.5 rounded-full md:hidden"
      >
        <span className="h-[1.5px] w-5 bg-white" />
        <span className="h-[1.5px] w-3.5 bg-white" />
      </button>
    </nav>
  );
}
