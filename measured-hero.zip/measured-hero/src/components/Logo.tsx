import { LOGO_PATH } from "../constants/assets";

export default function Logo() {
  return (
    <svg
      width={28}
      height={28}
      viewBox="0 0 256 256"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Measured logo"
    >
      <path d={LOGO_PATH} fill="white" />
    </svg>
  );
}
