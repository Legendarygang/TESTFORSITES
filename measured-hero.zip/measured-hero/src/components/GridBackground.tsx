import { useEffect, useRef, type RefObject } from "react";
import type { CursorPoint } from "../hooks/useSectionCursor";

interface GridBackgroundProps {
  sectionRef: RefObject<HTMLElement | null>;
  cursorRef: RefObject<CursorPoint>;
}

const EASE = 0.06;
const PARALLAX_SCALE = 16;

export default function GridBackground({ sectionRef, cursorRef }: GridBackgroundProps) {
  const gridRef = useRef<HTMLDivElement>(null);
  const eased = useRef<CursorPoint>({ x: 0, y: 0 });

  useEffect(() => {
    let raf = 0;

    const tick = () => {
      const section = sectionRef.current;
      const grid = gridRef.current;

      if (section && grid) {
        const rect = section.getBoundingClientRect();
        const cx = rect.width / 2;
        const cy = rect.height / 2;

        const targetX = ((cursorRef.current.x - cx) / cx) * PARALLAX_SCALE;
        const targetY = ((cursorRef.current.y - cy) / cy) * PARALLAX_SCALE;

        eased.current.x += (targetX - eased.current.x) * EASE;
        eased.current.y += (targetY - eased.current.y) * EASE;

        grid.style.transform = `translate(${eased.current.x}px, ${eased.current.y}px)`;
      }

      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [sectionRef, cursorRef]);

  return (
    <div
      ref={gridRef}
      className="pointer-events-none absolute inset-[-20px] z-0 opacity-10"
      aria-hidden="true"
    >
      <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="hero-grid" width={48} height={48} patternUnits="userSpaceOnUse">
            <path d="M 48 0 L 0 0 0 48" fill="none" stroke="#64748b" strokeWidth={0.6} />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#hero-grid)" />
      </svg>
    </div>
  );
}
