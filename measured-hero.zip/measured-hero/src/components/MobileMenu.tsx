const NAV_ITEMS = ["Device", "Real Stories", "Science", "Plans", "Reach Us"];

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[55] flex flex-col items-center justify-center bg-[#0a0a0a]"
      role="dialog"
      aria-modal="true"
    >
      {/* Close button */}
      <button
        type="button"
        onClick={onClose}
        aria-label="Close menu"
        className="liquid-glass animate-close-btn absolute right-5 top-5 flex h-11 w-11 items-center justify-center rounded-full sm:right-8 sm:top-6"
      >
        <span className="relative block h-4 w-4">
          <span className="absolute left-0 top-1/2 h-[1.5px] w-4 -translate-y-1/2 rotate-45 bg-white" />
          <span className="absolute left-0 top-1/2 h-[1.5px] w-4 -translate-y-1/2 -rotate-45 bg-white" />
        </span>
      </button>

      {/* Nav items */}
      <div className="flex flex-col items-center gap-2">
        {NAV_ITEMS.map((item, i) => (
          <button
            key={item}
            type="button"
            onClick={onClose}
            className="animate-menu-item text-3xl font-medium text-white/90 sm:text-4xl"
            style={{ animationDelay: `${100 + i * 60}ms` }}
          >
            {item}
          </button>
        ))}
      </div>

      {/* CTA */}
      <div
        className="animate-menu-item absolute bottom-10 left-1/2 -translate-x-1/2"
        style={{ animationDelay: `${100 + NAV_ITEMS.length * 60}ms` }}
      >
        <button
          type="button"
          onClick={onClose}
          className="liquid-glass flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium text-white"
        >
          <span className="h-2 w-2 rounded-full bg-green-400" />
          Reserve Yours
        </button>
      </div>
    </div>
  );
}
