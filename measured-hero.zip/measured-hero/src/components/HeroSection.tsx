import { useRef } from "react";
import GridBackground from "./GridBackground";
import SpotlightReveal from "./SpotlightReveal";
import { useSectionCursor } from "../hooks/useSectionCursor";
import { BG_IMAGE_1, OVERLAY_IMAGE } from "../constants/assets";

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const { targetRef, handleMouseMove } = useSectionCursor(sectionRef);

  return (
    <section
      ref={sectionRef}
      onMouseMove={handleMouseMove}
      className="font-helvetica-neue relative h-[100vh] w-full overflow-hidden bg-[#0a0a0a]"
    >
      {/* Layer 1 — grid background */}
      <GridBackground sectionRef={sectionRef} cursorRef={targetRef} />

      {/* Layer 2 — background image */}
      <div
        className="absolute inset-0 z-10 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${BG_IMAGE_1})` }}
        aria-hidden="true"
      />

      {/* Layer 3 — hero text */}
      <div className="absolute inset-x-0 top-20 z-20 flex justify-center sm:top-28 md:top-32">
        <h1
          className="select-none text-center font-serif text-[4.5rem] uppercase leading-[0.9] text-white xs:text-[5.5rem] sm:text-[10rem] md:text-[13rem] lg:text-[16rem]"
        >
          Measured
        </h1>
      </div>

      {/* Layer 4 — overlay image */}
      <img
        src={OVERLAY_IMAGE}
        alt=""
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 z-[25] h-full w-full object-cover"
      />

      {/* Layer 5 — spotlight reveal */}
      <SpotlightReveal sectionRef={sectionRef} cursorRef={targetRef} />
    </section>
  );
}
