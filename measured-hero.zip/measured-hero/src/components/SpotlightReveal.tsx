import { useEffect, useRef, type RefObject } from "react";
import type { CursorPoint } from "../hooks/useSectionCursor";
import { FRONT_VIDEO } from "../constants/assets";

interface SpotlightRevealProps {
  sectionRef: RefObject<HTMLElement | null>;
  cursorRef: RefObject<CursorPoint>;
}

const RADIUS = 260;
const LERP = 0.1;

export default function SpotlightReveal({ sectionRef, cursorRef }: SpotlightRevealProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const maskDivRef = useRef<HTMLDivElement>(null);
  const smooth = useRef<CursorPoint>({ x: 0, y: 0 });

  useEffect(() => {
    let raf = 0;
    let width = 0;
    let height = 0;

    const resize = () => {
      const section = sectionRef.current;
      const canvas = canvasRef.current;
      if (!section || !canvas) return;
      width = section.offsetWidth;
      height = section.offsetHeight;
      canvas.width = width;
      canvas.height = height;
    };

    resize();
    window.addEventListener("resize", resize);

    const tick = () => {
      const canvas = canvasRef.current;
      const maskDiv = maskDivRef.current;

      if (canvas && maskDiv && width && height) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const target = cursorRef.current;
          smooth.current.x += (target.x - smooth.current.x) * LERP;
          smooth.current.y += (target.y - smooth.current.y) * LERP;

          ctx.clearRect(0, 0, width, height);

          const gradient = ctx.createRadialGradient(
            smooth.current.x,
            smooth.current.y,
            0,
            smooth.current.x,
            smooth.current.y,
            RADIUS
          );
          gradient.addColorStop(0, "rgba(255,255,255,1)");
          gradient.addColorStop(0.4, "rgba(255,255,255,1)");
          gradient.addColorStop(0.6, "rgba(255,255,255,0.75)");
          gradient.addColorStop(0.75, "rgba(255,255,255,0.4)");
          gradient.addColorStop(0.88, "rgba(255,255,255,0.12)");
          gradient.addColorStop(1, "rgba(255,255,255,0)");

          ctx.fillStyle = gradient;
          ctx.fillRect(0, 0, width, height);

          const dataUrl = canvas.toDataURL();
          maskDiv.style.maskImage = `url(${dataUrl})`;
          maskDiv.style.webkitMaskImage = `url(${dataUrl})`;
          maskDiv.style.maskSize = "100% 100%";
          maskDiv.style.webkitMaskSize = "100% 100%";
          maskDiv.style.maskRepeat = "no-repeat";
          maskDiv.style.webkitMaskRepeat = "no-repeat";
        }
      }

      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, [sectionRef, cursorRef]);

  return (
    <>
      <canvas ref={canvasRef} className="hidden" aria-hidden="true" />
      <div ref={maskDivRef} className="pointer-events-none absolute inset-0 z-30">
        <video
          src={FRONT_VIDEO}
          autoPlay
          loop
          muted
          playsInline
          className="h-full w-full object-cover"
          style={{ clipPath: "inset(40% 0 0 0)" }}
        />
      </div>
    </>
  );
}
