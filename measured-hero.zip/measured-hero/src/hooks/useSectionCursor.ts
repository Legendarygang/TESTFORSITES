import { useRef, type RefObject } from "react";

export interface CursorPoint {
  x: number;
  y: number;
}

/**
 * Tracks the raw cursor position relative to a section element via a ref
 * (not React state) so downstream animation loops can read it every frame
 * without triggering re-renders.
 */
export function useSectionCursor(sectionRef: RefObject<HTMLElement | null>) {
  const targetRef = useRef<CursorPoint>({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    const el = sectionRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    targetRef.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  return { targetRef, handleMouseMove };
}
