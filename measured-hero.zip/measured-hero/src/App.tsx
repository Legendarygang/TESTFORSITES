import { useEffect, useState } from "react";
import Nav from "./components/Nav";
import MobileMenu from "./components/MobileMenu";
import HeroSection from "./components/HeroSection";

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = isMenuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isMenuOpen]);

  return (
    <div className="h-screen w-full overflow-hidden bg-white">
      <Nav onOpenMenu={() => setIsMenuOpen(true)} />
      <MobileMenu isOpen={isMenuOpen} onClose={() => setIsMenuOpen(false)} />
      <HeroSection />
    </div>
  );
}
