/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    screens: {
      xs: "420px",
      sm: "640px",
      md: "768px",
      lg: "1024px",
      xl: "1280px",
      "2xl": "1536px",
    },
    extend: {
      fontFamily: {
        inter: ["Inter", "sans-serif"],
        serif: ["'Instrument Serif'", "serif"],
        "helvetica-neue": ["'Helvetica Neue Roman'", "Helvetica Neue", "sans-serif"],
      },
    },
  },
  plugins: [],
};
